# Análisis de la Encuesta sobre la Percepción Pública de la Ciencia y la Tecnología (ENPECYT) 2017

Este repositorio concentra algunos análisis de la Encuesta sobre la Percepción Pública de la Ciencia y la Tecnología (ENPECYT) 2017 realizada por INEGI.

Los datos originales de la encuesta y la metodología se pueden encontrar [aquí](https://www.inegi.org.mx/programas/enpecyt/2017/default.html). 